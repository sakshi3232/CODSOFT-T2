from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


board = [None] * 9 
current_player = 'O'  #Player-O,Computer-X
game_finished = False

def is_winner(player_symbol):
    #rows
    for i in range(0, 9, 3):
        if board[i] == board[i+1] == board[i+2] == player_symbol:
            return True 
    #columns
    for i in range(3):
        if board[i] == board[i+3] == board[i+6] == player_symbol:
            return True
    #diagonals
    if board[0] == board[4] == board[8] == player_symbol:
        return True
    if board[2] == board[4] == board[6] == player_symbol:
        return True
    return False

def is_board_full():
    return None not in board

def reset_board():
    global board, game_finished
    board = [None] * 9
    game_finished = False

def find_best_move():
    best_score = float('-inf')
    best_move = None

    for i in range(9):
        if board[i] is None:
            board[i] = 'X'
            score = get_position_score(0, False)
            board[i] = None
            if score > best_score:
                best_score = score
                best_move = i
    return best_move

def get_position_score(depth, is_ai_turn):
    if is_winner('X'):
        return 10 - depth
    if is_winner('O'):
        return depth - 10
    if is_board_full():
        return 0

    if is_ai_turn:
        best_score = float('-inf')
        for i in range(9):
            if board[i] is None:
                board[i] = 'X'
                score = get_position_score(depth + 1, False)
                board[i] = None
                best_score = max(score, best_score)
        return best_score
    else:
        best_score = float('inf')
        for i in range(9):
            if board[i] is None:
                board[i] = 'O'
                score = get_position_score(depth + 1, True)
                board[i] = None
                best_score = min(score, best_score)
        return best_score

@app.route('/')
def home():
    return render_template('index.html')
@app.route('/move', methods=['POST'])
def make_move():
    global game_finished
    
    if game_finished:
        return jsonify({'error': 'Game already finished!'})

    move = request.json.get('cell')
    if not isinstance(move, int) or move < 0 or move > 8:
        return jsonify({'error': 'Invalid move!'})
    
    if board[move] is not None:
        return jsonify({'error': 'Cell already taken!'})
    board[move] = 'O'

    if is_winner('O'):
        game_finished = True
        return jsonify({
            'winner': 'player',
            'ai_move': None
        })

    if is_board_full():
        game_finished = True
        return jsonify({
            'winner': 'tie',
            'ai_move': None
        })

    ai_move = find_best_move()
    board[ai_move] = 'X'

    if is_winner('X'):
        game_finished = True
        return jsonify({
            'winner': 'computer',
            'ai_move': ai_move
        })

    if is_board_full():
        game_finished = True
        return jsonify({
            'winner': 'tie',
            'ai_move': ai_move
        })

    return jsonify({
        'winner': None,
        'ai_move': ai_move
    })

@app.route('/reset', methods=['POST'])
def reset_game():
    reset_board()
    return jsonify({'status': 'ok'})

@app.route('/reset-all', methods=['POST'])
def reset_all():
    #Reset
    reset_board()
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(debug=True)